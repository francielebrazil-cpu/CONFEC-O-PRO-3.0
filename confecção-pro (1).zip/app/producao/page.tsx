'use client'

import React from 'react'
import AppWrapper from '@/components/AppWrapper'
import { Plus, Filter, ArrowRight, Clock, CheckCircle2, AlertCircle } from 'lucide-react'

const kanbanData = {
  'Aguardando': [
    { id: 'OP-2024-002', client: 'Estilo Urbano', product: 'Calça Jeans Slim', quantity: 200, priority: 'Média' },
    { id: 'OP-2024-005', client: 'Zattini', product: 'Jaqueta Corta Vento', quantity: 150, priority: 'Alta' },
  ],
  'Corte': [
    { id: 'OP-2024-006', client: 'Dafiti', product: 'Camisa Polo Piquet', quantity: 400, priority: 'Baixa' },
  ],
  'Costura': [
    { id: 'OP-2024-001', client: 'Moda Brasil', product: 'Camiseta Básica Algodão', quantity: 500, priority: 'Alta' },
    { id: 'OP-2024-004', client: 'C&A', product: 'Bermuda Sarja', quantity: 350, priority: 'Média' },
  ],
  'Acabamento': [
    { id: 'OP-2024-007', client: 'Riachuelo', product: 'Saia Midi Linho', quantity: 120, priority: 'Alta' },
  ],
  'Concluído': [
    { id: 'OP-2024-003', client: 'Lojas Renner', product: 'Vestido Verão Florido', quantity: 1000, priority: 'Média' },
  ]
}

export default function ProductionPage() {
  return (
    <AppWrapper>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">Fluxo de Produção</h2>
          <p className="text-slate-500">Acompanhe o status de cada ordem de produção em tempo real.</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-xl font-bold hover:bg-slate-50 transition-all">
            <Filter size={20} />
            <span>Filtrar</span>
          </button>
          <button className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
            <Plus size={20} />
            <span>Nova OP</span>
          </button>
        </div>
      </div>

      <div className="flex gap-6 overflow-x-auto pb-6 -mx-4 px-4 lg:mx-0 lg:px-0 scrollbar-hide">
        {Object.entries(kanbanData).map(([column, items]) => (
          <div key={column} className="flex-shrink-0 w-80">
            <div className="flex items-center justify-between mb-4 px-2">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900">{column}</h3>
                <span className="bg-slate-200 text-slate-600 text-xs font-bold px-2 py-0.5 rounded-full">
                  {items.length}
                </span>
              </div>
              <button className="text-slate-400 hover:text-slate-600">
                <Plus size={18} />
              </button>
            </div>

            <div className="space-y-4">
              {items.map((item) => (
                <div key={item.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-200 hover:shadow-md transition-all cursor-grab active:cursor-grabbing">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.id}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      item.priority === 'Alta' ? 'bg-red-100 text-red-600' :
                      item.priority === 'Média' ? 'bg-amber-100 text-amber-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      {item.priority}
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-900 mb-1">{item.client}</h4>
                  <p className="text-sm text-slate-500 mb-4">{item.product}</p>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                    <div className="flex items-center gap-1 text-slate-400">
                      <Clock size={14} />
                      <span className="text-xs font-medium">{item.quantity} pçs</span>
                    </div>
                    <button className="text-indigo-600 hover:bg-indigo-50 p-1.5 rounded-lg transition-colors">
                      <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </AppWrapper>
  )
}
