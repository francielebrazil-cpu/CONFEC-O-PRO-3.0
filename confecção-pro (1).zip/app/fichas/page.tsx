'use client'

import React from 'react'
import AppWrapper from '@/components/AppWrapper'
import { Plus, Search, ExternalLink, Download, Eye } from 'lucide-react'
import Image from 'next/image'

const technicalSheets = [
  { 
    id: 'FT-001', 
    name: 'Camiseta Básica Algodão', 
    category: 'Masculino', 
    lastUpdate: '10/03/2024', 
    image: 'https://picsum.photos/seed/tshirt/400/500',
    materials: ['Algodão 30.1', 'Linha Poliéster', 'Etiqueta Gola']
  },
  { 
    id: 'FT-002', 
    name: 'Calça Jeans Slim Fit', 
    category: 'Feminino', 
    lastUpdate: '05/03/2024', 
    image: 'https://picsum.photos/seed/jeans/400/500',
    materials: ['Jeans com Elastano', 'Zíper 15cm', 'Botão Metal']
  },
  { 
    id: 'FT-003', 
    name: 'Vestido Verão Florido', 
    category: 'Feminino', 
    lastUpdate: '12/03/2024', 
    image: 'https://picsum.photos/seed/dress/400/500',
    materials: ['Viscose Estampada', 'Elástico 2cm', 'Linha Nylon']
  },
  { 
    id: 'FT-004', 
    name: 'Jaqueta Corta Vento', 
    category: 'Unissex', 
    lastUpdate: '08/03/2024', 
    image: 'https://picsum.photos/seed/jacket/400/500',
    materials: ['Nylon Impermeável', 'Zíper Tratorado', 'Cordão Ajuste']
  },
]

export default function TechnicalSheetsPage() {
  return (
    <AppWrapper>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">Fichas Técnicas</h2>
          <p className="text-slate-500">Detalhamento de materiais, medidas e processos de cada produto.</p>
        </div>
        <button className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
          <Plus size={20} />
          <span>Nova Ficha</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-50 flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por nome ou código..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 rounded-lg outline-none transition-all text-sm"
            />
          </div>
          <select className="bg-slate-50 border-transparent rounded-lg px-3 py-2 text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all">
            <option>Todas as Categorias</option>
            <option>Masculino</option>
            <option>Feminino</option>
            <option>Infantil</option>
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-6">
          {technicalSheets.map((sheet) => (
            <div key={sheet.id} className="group bg-white border border-slate-100 rounded-2xl overflow-hidden hover:border-indigo-200 hover:shadow-lg transition-all flex flex-col">
              <div className="relative aspect-[4/5] overflow-hidden">
                <Image 
                  src={sheet.image} 
                  alt={sheet.name} 
                  fill 
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                  <a 
                    href={sheet.image} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="p-2 bg-white rounded-full text-slate-900 hover:bg-indigo-600 hover:text-white transition-colors"
                    title="Ver imagem original"
                  >
                    <ExternalLink size={20} />
                  </a>
                  <button className="p-2 bg-white rounded-full text-slate-900 hover:bg-indigo-600 hover:text-white transition-colors">
                    <Eye size={20} />
                  </button>
                </div>
              </div>
              
              <div className="p-4 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{sheet.id}</span>
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full uppercase">{sheet.category}</span>
                </div>
                <h4 className="font-bold text-slate-900 mb-2">{sheet.name}</h4>
                
                <div className="mt-auto">
                  <p className="text-[10px] text-slate-400 mb-3">Materiais principais:</p>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {sheet.materials.map(m => (
                      <span key={m} className="text-[9px] bg-slate-50 text-slate-600 px-1.5 py-0.5 rounded border border-slate-100">{m}</span>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between pt-3 border-t border-slate-50">
                    <span className="text-[10px] text-slate-400">Atualizado: {sheet.lastUpdate}</span>
                    <button className="text-slate-400 hover:text-indigo-600 transition-colors">
                      <Download size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppWrapper>
  )
}
