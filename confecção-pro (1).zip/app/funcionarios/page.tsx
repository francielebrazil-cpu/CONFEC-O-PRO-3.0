'use client'

import React from 'react'
import AppWrapper from '@/components/AppWrapper'
import { Plus, Search, MoreVertical, Mail, Phone, MapPin } from 'lucide-react'
import Image from 'next/image'

const employees = [
  { id: 1, name: 'Ana Silva', role: 'Costureira', email: 'ana.silva@email.com', phone: '(11) 98765-4321', status: 'Ativo', avatar: 'https://picsum.photos/seed/ana/100/100' },
  { id: 2, name: 'Carlos Oliveira', role: 'Cortador', email: 'carlos.o@email.com', phone: '(11) 97654-3210', status: 'Ativo', avatar: 'https://picsum.photos/seed/carlos/100/100' },
  { id: 3, name: 'Maria Santos', role: 'Acabamento', email: 'maria.s@email.com', phone: '(11) 96543-2109', status: 'Férias', avatar: 'https://picsum.photos/seed/maria/100/100' },
  { id: 4, name: 'João Pereira', role: 'Modelista', email: 'joao.p@email.com', phone: '(11) 95432-1098', status: 'Ativo', avatar: 'https://picsum.photos/seed/joao/100/100' },
]

export default function EmployeesPage() {
  return (
    <AppWrapper>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">Funcionários</h2>
          <p className="text-slate-500">Gerencie sua equipe e informações de contato.</p>
        </div>
        <button className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
          <Plus size={20} />
          <span>Novo Funcionário</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-50 flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por nome, cargo ou email..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 rounded-lg outline-none transition-all text-sm"
            />
          </div>
          <div className="flex gap-2">
            <select className="bg-slate-50 border-transparent rounded-lg px-3 py-2 text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all">
              <option>Todos os Cargos</option>
              <option>Costureira</option>
              <option>Cortador</option>
              <option>Acabamento</option>
            </select>
            <select className="bg-slate-50 border-transparent rounded-lg px-3 py-2 text-sm outline-none focus:bg-white focus:border-indigo-500 transition-all">
              <option>Status: Ativo</option>
              <option>Status: Férias</option>
              <option>Status: Inativo</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 p-6">
          {employees.map((emp) => (
            <div key={emp.id} className="group bg-white border border-slate-100 rounded-2xl p-5 hover:border-indigo-200 hover:shadow-md transition-all relative">
              <button className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">
                <MoreVertical size={20} />
              </button>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="relative w-16 h-16 rounded-full overflow-hidden border-2 border-slate-100">
                  <Image 
                    src={emp.avatar} 
                    alt={emp.name} 
                    fill 
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{emp.name}</h4>
                  <p className="text-sm text-slate-500">{emp.role}</p>
                  <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    emp.status === 'Ativo' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {emp.status}
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-4 border-t border-slate-50">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Mail size={14} className="text-slate-400" />
                  <span>{emp.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Phone size={14} className="text-slate-400" />
                  <span>{emp.phone}</span>
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button className="flex-1 py-2 bg-slate-50 text-slate-600 rounded-lg text-xs font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors">
                  Ver Perfil
                </button>
                <button className="flex-1 py-2 bg-slate-50 text-slate-600 rounded-lg text-xs font-bold hover:bg-indigo-50 hover:text-indigo-600 transition-colors">
                  Diárias
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppWrapper>
  )
}
