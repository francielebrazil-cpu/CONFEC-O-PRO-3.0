'use client'

import React from 'react'
import AppWrapper from '@/components/AppWrapper'
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Save } from 'lucide-react'

const employees = [
  { id: 1, name: 'Ana Silva', role: 'Costureira' },
  { id: 2, name: 'Carlos Oliveira', role: 'Cortador' },
  { id: 3, name: 'Maria Santos', role: 'Acabamento' },
  { id: 4, name: 'João Pereira', role: 'Modelista' },
]

export default function DailyControlPage() {
  const [currentDate, setCurrentDate] = React.useState(new Date())

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
  }

  return (
    <AppWrapper>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-display font-bold text-slate-900">Controle de Diárias</h2>
          <p className="text-slate-500">Registre a presença e produção diária de cada funcionário.</p>
        </div>
        <button className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
          <Save size={20} />
          <span>Salvar Lançamentos</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-slate-200">
              <ChevronLeft size={20} />
            </button>
            <div className="flex items-center gap-2 font-bold text-slate-900 capitalize">
              <CalendarIcon size={20} className="text-indigo-600" />
              {formatDate(currentDate)}
            </div>
            <button className="p-2 hover:bg-white rounded-lg transition-colors border border-transparent hover:border-slate-200">
              <ChevronRight size={20} />
            </button>
          </div>
          <button className="text-sm text-indigo-600 font-bold hover:underline">Hoje</button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/30 text-slate-500 text-xs uppercase tracking-wider">
                <th className="px-6 py-4 font-medium">Funcionário</th>
                <th className="px-6 py-4 font-medium text-center">Presença</th>
                <th className="px-6 py-4 font-medium">Produção (Peças)</th>
                <th className="px-6 py-4 font-medium">Observações</th>
                <th className="px-6 py-4 font-medium">Valor Diária</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {employees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="text-sm font-bold text-slate-900">{emp.name}</div>
                    <div className="text-xs text-slate-500">{emp.role}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center">
                      <input 
                        type="checkbox" 
                        defaultChecked 
                        className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <input 
                      type="number" 
                      placeholder="0" 
                      className="w-24 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:bg-white focus:border-indigo-500 outline-none transition-all"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <input 
                      type="text" 
                      placeholder="Ex: Atraso, hora extra..." 
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:bg-white focus:border-indigo-500 outline-none transition-all"
                    />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1 text-sm font-medium text-slate-900">
                      <span className="text-slate-400">R$</span>
                      <input 
                        type="number" 
                        defaultValue="80.00" 
                        className="w-20 px-2 py-1 bg-transparent border-none focus:ring-0 outline-none text-right"
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-6 bg-slate-50/30 border-t border-slate-50 flex justify-end">
          <div className="text-right">
            <p className="text-xs text-slate-500 uppercase tracking-wider font-bold mb-1">Total do Dia</p>
            <p className="text-2xl font-display font-bold text-slate-900">R$ 320,00</p>
          </div>
        </div>
      </div>
    </AppWrapper>
  )
}
