'use client'

import React from 'react'
import AppWrapper from '@/components/AppWrapper'
import { 
  TrendingUp, 
  TrendingDown, 
  Package, 
  Users, 
  Clock, 
  CheckCircle2,
  AlertCircle,
  FileText,
  Calendar
} from 'lucide-react'

const stats = [
  { name: 'Produção Mensal', value: '12.450', change: '+12%', icon: Package, color: 'text-blue-600', bg: 'bg-blue-50' },
  { name: 'Lucro Estimado', value: 'R$ 45.200', change: '+8%', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { name: 'Funcionários Ativos', value: '24', change: '0%', icon: Users, color: 'text-indigo-600', bg: 'bg-indigo-50' },
  { name: 'Pedidos Pendentes', value: '18', change: '-5%', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
]

const recentOrders = [
  { id: 'OP-2024-001', client: 'Moda Brasil', product: 'Camiseta Básica Algodão', quantity: 500, status: 'Em Produção', deadline: '20/03/2024' },
  { id: 'OP-2024-002', client: 'Estilo Urbano', product: 'Calça Jeans Slim', quantity: 200, status: 'Aguardando', deadline: '25/03/2024' },
  { id: 'OP-2024-003', client: 'Lojas Renner', product: 'Vestido Verão Florido', quantity: 1000, status: 'Concluído', deadline: '15/03/2024' },
  { id: 'OP-2024-004', client: 'C&A', product: 'Bermuda Sarja', quantity: 350, status: 'Em Produção', deadline: '22/03/2024' },
]

export default function Dashboard() {
  return (
    <AppWrapper>
      <div className="mb-8">
        <h2 className="text-3xl font-display font-bold text-slate-900">Dashboard</h2>
        <p className="text-slate-500">Bem-vindo de volta, aqui está o resumo da sua confecção.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={`${stat.bg} ${stat.color} p-3 rounded-xl`}>
                <stat.icon size={24} />
              </div>
              <span className={`text-sm font-medium ${stat.change.startsWith('+') ? 'text-emerald-600' : stat.change === '0%' ? 'text-slate-400' : 'text-red-600'}`}>
                {stat.change}
              </span>
            </div>
            <h3 className="text-slate-500 text-sm font-medium">{stat.name}</h3>
            <p className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Orders Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex items-center justify-between">
            <h3 className="font-display font-bold text-lg">Ordens de Produção Recentes</h3>
            <button className="text-indigo-600 text-sm font-medium hover:underline">Ver todas</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                  <th className="px-6 py-3 font-medium">ID</th>
                  <th className="px-6 py-3 font-medium">Cliente / Produto</th>
                  <th className="px-6 py-3 font-medium">Qtd</th>
                  <th className="px-6 py-3 font-medium">Status</th>
                  <th className="px-6 py-3 font-medium">Prazo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-slate-900">{order.id}</td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-slate-900">{order.client}</div>
                      <div className="text-xs text-slate-500">{order.product}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{order.quantity}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        order.status === 'Concluído' ? 'bg-emerald-100 text-emerald-700' :
                        order.status === 'Em Produção' ? 'bg-blue-100 text-blue-700' :
                        'bg-amber-100 text-amber-700'
                      }`}>
                        {order.status === 'Concluído' ? <CheckCircle2 size={12} /> : 
                         order.status === 'Em Produção' ? <TrendingUp size={12} /> : 
                         <AlertCircle size={12} />}
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">{order.deadline}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Actions / Notifications */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <h3 className="font-display font-bold text-lg mb-4">Ações Rápidas</h3>
            <div className="grid grid-cols-2 gap-3">
              <button className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl hover:bg-indigo-50 hover:text-indigo-600 transition-all group">
                <Package className="mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium">Nova OP</span>
              </button>
              <button className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl hover:bg-indigo-50 hover:text-indigo-600 transition-all group">
                <Users className="mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium">Novo Func.</span>
              </button>
              <button className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl hover:bg-indigo-50 hover:text-indigo-600 transition-all group">
                <FileText className="mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium">Nova Ficha</span>
              </button>
              <button className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl hover:bg-indigo-50 hover:text-indigo-600 transition-all group">
                <Calendar className="mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium">Lançar Diária</span>
              </button>
            </div>
          </div>

          <div className="bg-indigo-600 p-6 rounded-2xl text-white shadow-lg shadow-indigo-200">
            <h3 className="font-display font-bold text-lg mb-2">Meta de Produção</h3>
            <p className="text-indigo-100 text-sm mb-4">Você atingiu 85% da meta mensal. Faltam apenas 1.550 peças!</p>
            <div className="w-full bg-indigo-500 rounded-full h-2.5 mb-4">
              <div className="bg-white h-2.5 rounded-full" style={{ width: '85%' }}></div>
            </div>
            <button className="w-full py-2 bg-white text-indigo-600 rounded-lg text-sm font-bold hover:bg-indigo-50 transition-colors">
              Ver Detalhes
            </button>
          </div>
        </div>
      </div>
    </AppWrapper>
  )
}
